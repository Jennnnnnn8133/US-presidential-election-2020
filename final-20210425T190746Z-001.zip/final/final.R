library(tidyverse)

# source
### demographic
# https://www.census.gov/acs/www/data/data-tables-and-tools/data-profiles/
# https://data.census.gov/cedsci/table?g=0100000US.04000.001&y=2019&d=ACS%205-Year%20Estimates%20Data%20Profiles&tid=ACSDP5Y2019.DP02&moe=false&tp=false&hidePreview=true

##### import voting data
df_vote_raw <- read_csv("data/2020_US_County_Level_Presidential_Results.csv")

df_state_abbv <- read_csv("data/states_abbv.csv") %>%
  rename(state = 1, state_abbv = 2)
df_vote_raw_2016 <- read_csv("data/2016_US_County_Level_Presidential_Results.csv")

##### clean voting data and join
df_vote_agg <- df_vote_raw %>% rename(state = state_name) %>% group_by(state) %>% summarise(across(matches("votes"), ~sum(.))) %>%
  mutate(votes_gop_per = votes_gop/total_votes, 
         votes_dem_per = votes_dem/total_votes) %>%
  left_join(df_state_abbv)

df_vote_agg_2016 <- df_vote_raw_2016 %>% rename(state_abbv = state_abbr) %>% group_by(state_abbv) %>% summarise(across(matches("votes"), ~sum(.))) %>%
  mutate(votes_gop_per_2016 = votes_gop/total_votes, 
         votes_dem_per_2016 = votes_dem/total_votes) %>%
  left_join(df_state_abbv) %>% select(state, votes_gop_per_2016, votes_dem_per_2016)

##### import demo and socio data
df_raw <- read_csv("data/DEMOGRAPHIC AND HOUSING ESTIMATES.csv")
df_raw %>% tail()
df_raw %>% glimpse()

df_raw2 <- read_csv("data/SOCIAL CHARACTERISTICS.csv")
df_raw2 %>% tail()
df_raw2 %>% glimpse()

##### subset demo and socio data
df_gender <- df_raw %>% select(matches("E")) %>% select(-matches("PE")) %>% select(GEO_ID:DP05_0004E)
df_gender <- df_gender %>% `colnames<-`(df_gender %>% head(1) %>% unlist() %>% unname() %>% str_to_lower() %>% str_remove_all("estimate!!") %>%
                             str_replace_all(" ", "-") %>% str_replace_all("!!", "_")) %>%
  rename(pop = 3, pop_m = 4, pop_f= 5) %>% select(-6) %>%
  filter(`geographic-area-name` !="Puerto Rico") %>%
  slice(-1) %>% mutate(across(-matches("id|geographic"), ~as.numeric(.))) %>%
  mutate(per_m = pop_m/pop, per_f = pop_f/pop)

df_age <- df_raw %>% select(matches("E")) %>% select(-matches("PE")) %>% select(-(DP05_0001E:DP05_0004E)) %>% select(GEO_ID:DP05_0024E)
df_age <- df_age %>% `colnames<-`(df_age %>% head(1) %>% unlist() %>% unname() %>% str_to_lower() %>% str_remove_all("estimate!!") %>%
                                    str_replace_all(" ", "-") %>% str_replace_all("!!", "_")) %>%
  rename(pop_00_05 =3, pop_05_09 =4, pop_10_14 =5, pop_15_19 =6, pop_20_24 =7, pop_25_34 =8,
         pop_35_44 =9, pop_45_54 =10, pop_55_59 =11, pop_65_64 =12, pop_65_74 =13, pop_75_84 =14,pop_85_up =15) %>% select(-(16:22)) %>%
  filter(`geographic-area-name` !="Puerto Rico") %>%
  slice(-1) %>% mutate(across(-matches("id|geographic"), ~as.numeric(.))) %>%
  left_join(df_gender %>% select(1:3)) %>% mutate(across(is.numeric, ~(./pop))) %>%
  select(-pop)

df_race <- df_raw %>% select(matches("E")) %>% select(-matches("PE")) %>% select(-(DP05_0001E:DP05_0032E)) %>% select(GEO_ID:DP05_0085E) %>% select(1:5, 7:8, 14, 22, 27)
df_race <- df_race %>% `colnames<-`(df_race %>% head(1) %>% unlist() %>% unname() %>% str_to_lower() %>% str_remove_all("estimate!!") %>%
                                    str_replace_all(" ", "-") %>% str_replace_all("!!", "_")) %>%
  rename(race_one = 4, race_two = 5, race_one_white = 6, race_one_black = 7, race_one_asian = 8,
         race_one_native_pasific = 9, race_one_other = 10) %>% select(-3) %>%
  filter(`geographic-area-name` !="Puerto Rico") %>%
  slice(-1) %>% mutate(across(-matches("id|geographic"), ~as.numeric(.))) %>%
  left_join(df_gender %>% select(1:3)) %>% mutate(across(is.numeric, ~(./pop))) %>%
  select(-pop)

df_vote <- df_raw %>% select(matches("E")) %>% select(-matches("PE")) %>% select(-(DP05_0001E:DP05_0085E))
df_vote <- df_vote %>% `colnames<-`(df_vote %>% head(1) %>% unlist() %>% unname() %>% str_to_lower() %>% str_remove_all("estimate!!") %>%
                                      str_replace_all(" ", "-") %>% str_replace_all("!!", "_")) %>%
  rename(unit_housing = 3, vote_all = 4, vote_m = 5, vote_f = 6) %>%
  filter(`geographic-area-name` !="Puerto Rico") %>%
  slice(-1) %>% mutate(across(-matches("id|geographic"), ~as.numeric(.))) %>%
  mutate(per_vote_m = vote_m/vote_all, per_vote_f = vote_f/vote_all)

df_relationship <- df_raw2 %>% select(matches("E")) %>% select(-matches("PE")) %>% select(-(DP02_0001E:DP02_0017E)) %>% select(GEO_ID:DP02_0024E)
df_relationship <- df_relationship %>% `colnames<-`(df_relationship %>% head(1) %>% unlist() %>% unname() %>% str_to_lower() %>% str_remove_all("estimate!!") %>%
                                      str_replace_all(" ", "-") %>% str_replace_all("!!", "_")) %>%
  rename(household = 3, household_householder = 4, household_spouse = 5, household_partner = 6, household_child = 7, household_relatives = 8, household_nrelatives =9) %>%
  filter(`geographic-area-name` !="Puerto Rico") %>%
  slice(-1) %>% mutate(across(-matches("id|geographic"), ~as.numeric(.))) %>%
  mutate(across(matches("household_"), ~(./household)))

df_marital <- df_raw2 %>% select(matches("E")) %>% select(-matches("PE")) %>% select(-(DP02_0001E:DP02_0024E)) %>% select(GEO_ID:DP02_0036E)
df_marital <- df_marital %>% `colnames<-`(df_marital %>% head(1) %>% unlist() %>% unname() %>% str_to_lower() %>% str_remove_all("estimate!!") %>%
                                      str_replace_all(" ", "-") %>% str_replace_all("!!", "_")) %>%
  rename(marital_m = 3, marital_nemarried_m = 4, marital_married_m = 5, marital_separated_m = 6, marital_widowed_m = 7, marital_divorce_m = 8, 
         marital_f = 9, marital_nemarried_f = 10, marital_married_f = 11, marital_separated_f = 12, marital_widowed_f = 13, marital_divorce_f = 14) %>%
  filter(`geographic-area-name` !="Puerto Rico") %>%
  slice(-1) %>% mutate(across(-matches("id|geographic"), ~as.numeric(.))) %>%
  mutate(across(matches("widow"), ~as.numeric(.))) %>%
  mutate(across(matches("marital_.*_m"), ~(./marital_m))) %>%
  mutate(across(matches("marital_.*_f"), ~(./marital_f))) %>%
  mutate(marital_nemarried = marital_nemarried_m + marital_nemarried_f, 
         marital_married = marital_married_m + marital_married_f, 
         marital_separated = marital_separated_m + marital_separated_f, 
         marital_widowed = marital_widowed_m + marital_widowed_f,
         marital_divorce = marital_divorce_m + marital_divorce_f)

df_educational_attainment <- df_raw2 %>% select(matches("E")) %>% select(-matches("PE")) %>% select(-(DP02_0001E:DP02_0058E)) %>% select(GEO_ID:DP02_0068E)
df_educational_attainment <- df_educational_attainment %>% `colnames<-`(df_educational_attainment %>% head(1) %>% unlist() %>% unname() %>% str_to_lower() %>% str_remove_all("estimate!!") %>%
                                      str_replace_all(" ", "-") %>% str_replace_all("!!", "_")) %>%
  rename(education = 3, education_js = 4, education_high = 5, education_high_gradu = 6, education_college = 7, 
         education_associate = 8, education_bachelor = 9, education_gradu_professional = 10) %>% select(-(11:12)) %>%
  filter(`geographic-area-name` !="Puerto Rico") %>%
  slice(-1) %>% mutate(across(-matches("id|geographic"), ~as.numeric(.))) %>%
  mutate(across(matches("education_"), ~(./education)))

##### join data
df_state_metric <- df_gender %>% 
  left_join(df_age, by = c("id", "geographic-area-name")) %>% 
  left_join(df_race, by = c("id", "geographic-area-name")) %>% 
  left_join(df_educational_attainment, by = c("id", "geographic-area-name")) %>% 
  left_join(df_marital, by = c("id", "geographic-area-name")) %>% 
  left_join(df_relationship, by = c("id", "geographic-area-name")) %>% 
  left_join(df_vote, by = c("id", "geographic-area-name")) %>%
  rename(state=2)

df_presidential_2020 <- df_state_metric %>% left_join(df_vote_agg, by = "state") %>%
  left_join(df_vote_agg_2016, by = "state") %>%
  mutate(gop_change = if_else(votes_gop_per > votes_gop_per_2016, "up", "down"),
         dem_change = if_else(votes_dem_per > votes_dem_per_2016, "up", "down"))

df_presidential_2020 

##### vizaulizing
plot_bachelor <- df_presidential_2020 %>%
  ggplot(aes(x = education_bachelor, y = votes_gop_per, color = gop_change)) +
  geom_point() +
  theme_bw() +
  scale_x_continuous(labels = scales::percent) +
  scale_y_continuous(labels = scales::percent)

plot_household_spouse <- df_presidential_2020 %>%
  ggplot(aes(x = household_spouse, y = votes_gop_per)) +
  geom_point() +
  theme_bw() +
  scale_x_continuous(labels = scales::percent) +
  scale_y_continuous(labels = scales::percent)

plot_pop_85_up <- df_presidential_2020 %>%
  ggplot(aes(x = pop_85_up, y = votes_gop_per, size = race_one_white)) +
  geom_point() +
  theme_bw() +
  scale_x_continuous(labels = scales::percent) +
  scale_y_continuous(labels = scales::percent)

plot_race_one_black <- df_presidential_2020 %>%
  ggplot(aes(x = race_one_black, y = votes_gop_per)) +
  geom_point() +
  theme_bw() +
  scale_x_continuous(labels = scales::percent) +
  scale_y_continuous(labels = scales::percent)

plot_bachelor %>%
  ggsave(filename = str_c("image/","plot_bachelor", ".png"), dpi = 600, height = 8, width = 12)
plot_household_spouse %>%
  ggsave(filename = str_c("image/","plot_household_spouse", ".png"), dpi = 600, height = 8, width = 12)
plot_pop_85_up %>%
  ggsave(filename = str_c("image/","plot_pop_85_up", ".png"), dpi = 600, height = 8, width = 12)
plot_race_one_black %>%
  ggsave(filename = str_c("image/","plot_race_one_black", ".png"), dpi = 600, height = 8, width = 12)

##### modeling
df_model <- df_presidential_2020 %>%
  mutate(vote_all_per = vote_all/pop, household_per = household/pop) %>%
  select(-c(id, state, state_abbv, pop_m, pop_f, education, marital_m, marital_f, 
            household, unit_housing, votes_gop, votes_dem, total_votes, votes_dem_per, vote_all, vote_m, vote_f, unit_housing,
            gop_change, dem_change,
            race_two, education_js, marital_nemarried, marital_nemarried, household_nrelatives, per_vote_f, pop_00_05, per_f, votes_dem_per_2016), -matches("marital_.*_m|marital_.*_f"))

df_model %>% glimpse()

library(caret)
model_glm <- glm(votes_gop_per ~ ., data = df_model, family = "binomial")
summary(model_glm)




